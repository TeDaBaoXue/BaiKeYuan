/*
??fun?????n,??????n??(??n)?????????? ,??10,??:-0.138095?
???fun?????????????,???????????
*/
#include<stdio.h>
#include<stdlib.h>
double fun(int n)
{
/*************************Begin*********************/
    int pri=3,i=2,j,ju=1;//pri-->prime,ju-->judge
    double s=0.5,t=0.5;
    while (pri<=n){
        for (j=2;j<pri;j++){
            if (pri%j==0) {
                ju=0;
                break;
            }
        }
        if (ju) {
            if (i%2) {t=i*1.0/pri;}
            else {t=-i*1.0/pri;}
            s+=t;
            i++;
        }
        pri+=2;
        ju=1;
    }
    return s;
/**************************End**********************/
}
int main()
{
	int n;
	double s,x;
	FILE *in,*out;
	printf("??n:");
	scanf("%d",&n);
	s=fun(n);
	printf("%lf\n",s);
	/*****************/
	in=fopen("in2019-2-1-2.dat","r");
	out=fopen("out2019-2-1-2.dat","w");
	while(!feof(in))
	{
		fscanf(in,"%d",&n);
		fprintf(out,"%lf\n",fun(n));
	}
            fclose(in);
            fclose(out);
	system("pause");
	return 0;	
}
