/*
??fun?????n,??????n??? ,
??10 ,??:0.206936????fun?????????????,???????????
*/
#include<stdio.h>
#include<stdlib.h>
double fun(int n)
{
/**********************Begin*********************/
    double s=0,t=-1,i=1,j=2;
    while (n-->0) {//这个"趋于"写成-->就很灵性
        t*=-i/j;
        s+=t;
        i+=2;
        j+=2;
    }
    return s;
/**********************End*********************/
}
int main()
{
	int n;
	double s;
	FILE *in,*out;
	printf("??n:");
	scanf("%d",&n);
	s=fun(n);
	printf("%lf\n",s);
	/***********************/
	in=fopen("in2019-2-3-2.dat","r");
	out=fopen("out2019-2-3-2.dat","w");
	while(!feof(in))
	{
		fscanf(in,"%d",&n);
		fprintf(out,"%lf\n",fun(n));
	}
            fclose(in);
            fclose(out);
	system("pause");
	return 0;
}
