/*
??fun()??????n,??????? s=1+1/22+1/333+......+1/nn...nn
???n=5,s=1.04870057 ,??:?????????? 
????main?????????????,????fun??????????????????
*/ 
#include<stdio.h>
#include<stdlib.h>
double fun(int n)
{
	/*********Begin*********/
    double s=0,t=1;
    int i,j;
    for (i=1;i<=n;i++){
        t=i;
        for (j=1;j<i;j++){
            t=t*10+i;
        }
        s+=1/t;
    }
    return s;
	/*********End*********/
}
int main()
{
	FILE *in,*out;
	int n,i;
	double s;
	scanf("%d",&n);
	s=fun(n);
	printf("%.8lf\n",s);
	/**************/
	in=fopen("in96.dat","r");
	out=fopen("out96.dat","w");
	while(!feof(in))
	{
		fscanf(in,"%d",&n);
		fprintf(out,"%.8lf\n",fun(n));
	}
	fclose(in);
	fclose(out);
       system("pause");
	return 0;
}