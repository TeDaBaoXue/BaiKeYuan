/*    ????,????(3?3?)???(?????)?
??,???????:  
         100  200  300
         400  500  600
         700  800  900
????:  
         100  400  700
         200  500  800
         300  600  900
    ??: ?????????program.c??
    ???????main???????????,????fun????????????????*/



#include <stdio.h>
#include<stdlib.h>
void fun(int array[3][3])
{


    /**********  Begin  **********/
    int i,j,k,t;
    for (i=0;i<3-1;i++) {
        for (j=i+1;j<3;j++) {
            t=array[i][j];
            array[i][j]=array[j][i];
            array[j][i]=t;
        }
    }
  
  
  
  
    /**********   End  ***********/


}

void NONO( )
{/* ??????????,??????,?? fun ??,
    ????,????? */
    int i,j;
    FILE  *wf ,*in;
    int array[3][3]={{100,200,300},
                     {400,500,600},
                     {700,800,900}};
    in=fopen("a11.in","r");
    for(i=0;i<3;i++)
    {   for(j=0;j<3;j++)
	fscanf(in,"%d",&array[i][j]);
     }
    wf = fopen("a11.out", "w") ;
    fun(array);
    for(i=0;i<3;i++)
    {   for(j=0;j<3;j++)
	fprintf(wf,"%7d\n",array[i][j]);
     }

    fclose(wf) ;
    fclose(in);
}

int main()
{
    int i,j;
    int array[3][3]={{100,200,300},
                     {400,500,600},
                     {700,800,900}};
     for (i=0;i<3;i++)
    {    for (j=0;j<3;j++)
         printf("%7d",array[i][j]);
         printf("\n");
    }
    fun(array);
    printf("Converted array:\n");
    for(i=0;i<3;i++)
    {   for(j=0;j<3;j++)
        printf("%7d",array[i][j]);
        printf("\n");
    }
 NONO( );
 system("pause");
 return 0;
}

