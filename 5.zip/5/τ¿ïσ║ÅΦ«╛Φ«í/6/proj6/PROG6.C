/*?????fun,????:?????1??????m??????xx?????,????????k???
??,??17,????4 6 8 9 10 12 14 15 16?
??:??????????
????main?????????????,????fun????????????????
????:*/ 
//#include<conio.h>
#include<math.h>
#include<stdio.h>
#include<stdlib.h>
int fun(int m, int xx[])
{
/**********Begin*******/
    int i=4,j,k=0,ju=1;
    if (m>4) {
        for (i=4;i<m;i++) {
            for (j=2;j<i;j++) {
                if (i%j==0) {
                    ju=0;
                    break;
                }
            }
            if (ju==0) {
                xx[k]=i;
                k++;
            }
            ju=1;
        }
    }
    else {
        k=0;
    }
    return k;
/*********End*********/  
}
int main()
{
  FILE *wf,*in;
  int m, n, zz[100];
  printf("\nPlease enter an integer number between 10 and 100: ");
  scanf("%d",&n);
  m=fun(n,zz);
  printf("\n\nThere are %d non-prime numbers less than %d: ",m,n);
  for(n=0;n<m;n++)
    printf("\n %4d",zz[n]);
/******************************/
  wf=fopen("1.out","w");
  in=fopen("1.in","r");
  fscanf(in,"%d",&n);
  m=fun(n,zz);
  for(n=0;n<m;n++)
    fprintf(wf,"%d\n",zz[n]);
  fclose(wf);
 fclose(in);
/*****************************/
//system("pause");
return 0;
}
