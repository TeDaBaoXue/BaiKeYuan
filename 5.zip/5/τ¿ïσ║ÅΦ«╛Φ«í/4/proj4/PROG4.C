/*????int fun(int lim, int aa[MAX]),??????????????lim????????aa???,
??????????????? 
??:?????????? 
????main?????????????,????fun???????????????? 
????: */
#include<stdio.h>
#include<stdlib.h>
#define MAX 100
int fun(int lim, int aa[MAX])
{
/**********Begin**********/
    int i,j,n=1,isp=1;
    aa[0]=2;
    for (i=3;i<=lim;i+=2) {
        for (j=2;j<i;j++) {
            if (i%j==0) {
                isp=0;
                break;
            }
        }
        if (isp) {
            aa[n]=i;
            n++;
        }
        isp=1;
    }
    return n;

/**********End**********/  
}
int main()
{
  FILE *wf,*in;
  int limit,i,k,sum;
  int aa[MAX];
  printf("??????");
  scanf("%d",&limit);
  sum=fun(limit,aa);        
  for(i=0;i<sum;i++)
     {
      if(i%10==0&&i!=0)    /*????10??*/
         printf("\n ");
      printf("%5d ",aa[i]);
    }
/******************************/
  wf=fopen("2.out","w");
  in=fopen("2.dat","r");
  fscanf(in,"%d",&k);
  sum=fun(k,aa);        
  for(i=0;i<sum;i++)
      fprintf(wf,"%d\n",aa[i]);
  fclose(wf);
  fclose(in);
/*****************************/
system("pause");
return 0;
}