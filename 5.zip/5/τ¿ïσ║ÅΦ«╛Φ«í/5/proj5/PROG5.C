/*?????fun,??????:????????????,??????????????????????? 
??,????????? 
    1  3  5  7  9 
    2  9  9  9  4 
    6  9  9  9  8 
    1  3  5  7  0 
?????61? 
??:?????????? 
????main?????????????,????fun???????????????? 
    ????:*/
#include<stdio.h>
#include<stdlib.h>
#define  M  4
#define  N  5
int fun( int a [M][N])
{
     /***************Begin************/
     int s=0,i,j;
     for (i=0;i<M;i++) {
         if (i==0||i==M-1) {
             for (j=0;j<N;j++) {
                 s+=a[i][j];
             }
         }
         else {
             s+=a[i][0]+a[i][N-1];
         }
     }
     return s;

     /*************** End ************/
}
int main()
{
  FILE *wf,*in;
  int aa[M][N]={{1,3,5,7,9},{2,9,9,9,4},{6,9,9,9,8},{1,3,5,7,10}};
  int i, j, y;
  printf ("The original data is :\n ");
  for(i=0; i<M;i++)
     {for (j=0; j<N;j++) 
          printf("%6d ",aa[i][j]);
      printf("\n ");
     }
  y=fun(aa);
  printf("\nThe sun: %d\n ",y);
  printf("\n ");
/******************************/
 in=fopen("in10.dat","r");
  wf=fopen("out10.dat","w");
  for(i=0;i<M;i++)
    for(j=0;j<N;j++)
      fscanf(in,"%d",&aa[i][j]);
  y=fun(aa);
  fprintf (wf,"%d",y);
  fclose(wf);
  fclose(in);
/*****************************/
system("pause");
} 
